<?php
/**
 *
 * @version $Id: exceptions.php 82 2017-03-21 13:01:03Z Scanialady $
 * Knowledge Base extension for the phpBB Forum Software package (deutsch)
 * @copyright (c) 2017, kinerity, https://www.acsyste.com
 * @license GNU General Public License, version 2 (GPL-2.0)
 *
 */

/**
* DO NOT CHANGE
*/
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ‚ ‘ ’ « » „ “ ” …
//

$lang = array_merge($lang, array(
	'EXCEPTION_FIELD_MISSING'		=> 'Erforderliches Feld fehlt',
	'EXCEPTION_INVALID_ARGUMENT'	=> 'Ungültiges Argument festgelegt für `%1$s`. Grund: %2$s',
	'EXCEPTION_OUT_OF_BOUNDS'		=> 'Das Feld `%1$s` erhielt Daten über seine Begrenzung hinaus',
	'EXCEPTION_TOO_LONG'			=> 'Die Eingabe war länger als die maximale Länge.',
	'EXCEPTION_NOT_UNIQUE'			=> 'Die Eingabe war nicht einzigartig.',
	'EXCEPTION_UNEXPECTED_VALUE'	=> 'Das Feld `%1$s` erhielt unerwartete Daten. Grund: %2$s',
	'EXCEPTION_ILLEGAL_CHARACTERS'	=> 'Die Eingabe enthielt unerlaubte Zeichen.',
));
