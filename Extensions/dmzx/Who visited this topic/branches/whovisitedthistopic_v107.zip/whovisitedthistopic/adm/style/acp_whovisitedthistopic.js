jQuery(window).load(function(){
	jQuery('#WhoVisitedThisTopic').fadeOut(1500);
});