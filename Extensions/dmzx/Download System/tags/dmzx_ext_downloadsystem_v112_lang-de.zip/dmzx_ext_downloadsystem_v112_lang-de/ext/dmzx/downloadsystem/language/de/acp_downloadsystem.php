<?php
/**
*
* @version §Id§
* @package phpBB Extension - Download System (Deutsch)
* @copyright (c) 2019 dmzx - https://www.dmzx-web.net
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ‚ ‘ ’ « » „ “ ” …
//

$lang = array_merge($lang, array(
	'ACP_ADD'							=> 'Hinzufügen',
	'ACP_ALL_DOWNLOADS'					=> 'Alle Downloads',
	'ACP_ANNOUNCE_ENABLE'				=> 'Neue Downloads ankündigen',
	'ACP_ANNOUNCE_ENABLE_EXPLAIN'		=> 'Wenn aktiviert, werden neue Downloads in einem bestimmten Forum angekündigt.',
	'ACP_ANNOUNCE_LOCK'					=> 'Ankündigung sperren',
	'ACP_ANNOUNCE_LOCK_EXPLAIN'			=> 'Wenn aktiviert, wird das Ankündigungsthema gesperrt.',
	'ACP_ANNOUNCE_ID'					=> 'Ankündigungsforum',
	'ACP_ANNOUNCE_ID_EXPLAIN'			=> 'Gib hier die ID des Forums ein, in dem du neue Downloads ankündigen möchtest.',
	'ACP_ANNOUNCE_MSG'					=> 'Hallo,

wir haben einen neuen Download!

[b]Titel:[/b] %1$s
[b]Beschreibung:[/b] %2$s
[b]Kategorie:[/b] %3$s
[b]Klicke %4$s, um zur Downloadseite zu gehen![/b]

Viel Freude damit!',
	'ACP_ANNOUNCE_SETTINGS'				=> 'Einstellungen Ankündigung',
	'ACP_ANNOUNCE_TITLE'				=> '%1$s',
	'ACP_CAT_NAME_SHOW_YES'				=> 'Ja',
	'ACP_CAT_NAME_SHOW_NO'				=> 'Nein',
	'ACP_NEW_CAT_NAME_SHOW'				=> 'In der Upload-Übersicht anzeigen',
	'ACP_NEW_CAT_NAME_SHOW_EXPLAIN'		=> 'Kategorie im Upload-Bereich für Gruppen anzeigen, welche hochladen dürfen.<br /><strong>Hinweis:</ strong> Administratoren können immer alle Kategorien im Upload-Bereich sehen.',
	'ACP_ANNOUNCE_UP'					=> 'Download noch einmal ankündigen',
	'ACP_ANNOUNCE_UP_EXPLAIN'			=> 'Aktiviere dies, wenn du den Download noch einmal ankündigen möchtest. Die Nachricht wird als Aktualisierungsnachricht gesendet.',
	'ACP_ANNOUNCE_UP_MSG'				=> 'Hallo,

wir haben einen aktualisierten Download!

[b]Titel:[/b] %1$s

[b]Beschreibung:[/b] %2$s

[b]Kategorie:[/b] %3$s

[b]Klicke %4$s, um zu dieser Kategorie zu gehen![/b]

Viel Freude damit!',
	'ACP_ANNOUNCE_UP_TITLE'					=> '[UPD] %1$s',
	'ACP_BASIC'								=> 'Grundeinstellungen',
	'ACP_CAT'								=> 'Kategorie',
	'ACP_CAT_SUB'							=> 'Kategorie mit Unterkategorie',
	'ACP_CATEGORIES'						=> 'Kategorien',
	'ACP_CAT_DELETE'						=> 'Kategorie löschen',
	'ACP_CAT_DELETE_DONE'					=> 'Deine Kategorie wurde erfolgreich gelöscht.',
	'ACP_CAT_DELETE_EXPLAIN'				=> 'Hier kannst du eine Kategorie löschen.',
	'ACP_CAT_EDIT_DONE'						=> 'Deine Kategorie wurde erfolgreich aktualisiert.',
	'ACP_CAT_EXIST'							=> 'Der Ordnername existiert bereits auf deinem Webspace!',
	'ACP_CAT_EXPLAIN'						=> 'Gib hier die Kategorie ein, in welcher dein Download gelistet werden soll.',
	'ACP_CAT_INDEX'							=> 'Kategorie-Übersicht',
	'ACP_CAT_NAME_ERROR'					=> 'Du musst einen Ordnernamen für deine Kategorie eingeben!',
	'ACP_CAT_NEW'							=> 'Eine neue Kategorie hinzufügen',
	'ACP_CAT_NEW_DONE'						=> 'Deine neue Kategorie wurde hinzugefügt, und der zugehörige Ordner erfolgreich auf deinem Webspace erstellt!',
	'ACP_CAT_NEW_EXPLAIN'					=> 'Hier kannst du eine neue Kategorie hinzufügen.',
	'ACP_CAT_NOT_EXIST'						=> 'Die angefragte Kategorie existiert nicht!',
	'ACP_CAT_SELECT'						=> 'Hier kannst du eine Kategorie hinzufügen, bearbeiten oder löschen.',
	'ACP_CAT_OF'							=> 'von',
	'ACP_CLICK'								=> 'hier',
	'ACP_CONFIG_SUCCESS'					=> 'Die Konfiguration wurde erfolgreich aktualisiert.',
	'ACP_COPY_NEW'							=> 'Als Entwurf kopieren',
	'ACP_COST_ERROR'						=> 'Du kannst keine negativen Kosten für einen Download einstellen!<br />Gib 0 ein, um es kostenlos zu machen, oder irgendeinen positiven Wert.',
	'ACP_COST_EXPLAIN'						=> 'Hier kannst du einstellen, wieviele %1$s ein Benutzer für diesen Download zahlen muss. Setze 0 ein, um den Download kostenlos anzubieten.',
	'ACP_COST_FREE'							=> 'Kostenlos',
	'ACP_COST_SHORT'						=> 'Kosten',
	'ACP_DELETE_HAS_FILES'					=> 'Es befinden sich noch Dateien in dieser Kategorie!<br />Bitte verschiebe diese zuerst in eine andere Kategorie, oder lösche sie!',
	'ACP_DELETE_SUB_CATS'					=> 'Bitte lösche zuerst die Unterkategorien!',
	'ACP_DEL_CAT'							=> 'Bist du sicher, dass du die Kategorie <strong>%1$s</strong> löschen möchtest?<br />Wenn keine Downloads mehr darin sind, wird der physische Ordner auf deinem Webserver ebenfalls gelöscht!',
	'ACP_DEL_CAT_EXPLAIN'					=> 'Hier kannst du eine existierende Kategorie löschen.',
	'ACP_DEL_DOWNLOAD'						=> 'Lösche einen Download',
	'ACP_DEL_DOWNLOADS_TO'					=> 'Verschiebe Downloads nach ',
	'ACP_DEL_DOWNLOAD_YES'					=> 'Kategorie mitsamt den Downloads löschen?',
	'ACP_DEL_SUBS'							=> 'Lösche Unterkategorien',
	'ACP_DEL_SUBS_TO'						=> 'Verschiebe Unterkategorien nach',
	'ACP_DEL_SUBS_YES'						=> 'Kategorie mitsamt Unterkategorien löschen?',
	'ACP_DOWNLOADS'							=> 'Downloads',
	'ACP_DOWNLOAD_DELETED'					=> 'Dein Download wurde erfolgreich gelöscht.',
	'ACP_DOWNLOAD_UPDATED'					=> 'Dein Download wurde erfolgreich aktualisiert',
	'ACP_DOWNLOAD_SYSTEM'					=> 'Download System',
	'ACP_EDIT_CAT'							=> 'Kategorie bearbeiten',
	'ACP_EDIT_CAT_EXPLAIN'					=> 'Hier kannst du eine existierende Kategorie bearbeiten.',
	'ACP_EDIT_DOWNLOADS'					=> 'Downloads bearbeiten',
	'ACP_EDIT_DOWNLOADS_EXPLAIN'			=> 'Hier kannst du den ausgewählten Download bearbeiten.',
	'ACP_EDIT_FILENAME'						=> 'Gespeicherte Datei',
	'ACP_EDIT_FILENAME_EXPLAIN'				=> '<strong>WICHTIG:</strong> Wenn Sie den Dateinamen hier ändern, wird nicht weiter geprüft, ob die Datei wirklich auf Ihrem Webspace vorhanden ist. <strong>Du musst die neue Datei über FTP hochladen, und die alte manuell löschen!</strong>',
	'ACP_EDIT_SUB_CAT_EXPLAIN'				=> 'Der bereits erstellte Unterordner kann nicht bearbeitet werden. Wenn du einen anderen Unterordner haben möchtest, musst du die aktuelle Kategorie löschen, und eine neue erstellen!',
	'ACP_FILE_TOO_BIG'						=> 'Die Datei ist größer, als dein Hoster erlaubt!',
	'ACP_DL_ERROR_CATEGORY_IMAGE'			=> 'Bei deinem Kategoriebild ist ein Fehler aufgetreten:',
	'ACP_FORUM_ID_ERROR'					=> 'Die angegebene Forum-ID existiert nicht!',
	'ACP_EDS_INDEX'							=> 'Download System',
	'ACP_MANAGE_DOWNLOADS_EXPLAIN'			=> 'Hier kannst du deine Downloads hinzufügen, bearbeiten oder löschen: <code>[URL]</code>.',
	'ACP_MULTI_DOWNLOAD'					=> '%d Downloads',
	'ACP_NEED_DATA'							=> 'Du musst alle Felder ausfüllen!',
	'ACP_NEW_ADDED'							=> 'Dein Eintrag wurde der Datenbank erfolgreich hinzugefügt.',
	'ACP_NEW_CAT'							=> 'Neue Kategorie',
	'ACP_NEW_CAT_DESC'						=> 'Beschreibung der Kategorie',
	'ACP_NEW_CAT_DESC_EXPLAIN'				=> 'Gib eine nützliche Beschreibung deiner neuen Kategorie ein.<br />BBCodes, Smilies und Links werden automatisch erkannt.',
	'ACP_NEW_CAT_NAME'						=> 'Kategoriename',
	'ACP_NEW_CAT_PARENT'					=> 'Übergeordnete Kategorie',
	'ACP_NEW_COPY_DOWNLOAD'					=> 'Neuer Download mit Kopie',
	'ACP_NEW_COPY_DOWNLOAD_EXPLAIN'			=> 'Du hast ausgewählt, einen bereits existierenden Download für deinen neuen zu kopieren. Das spart ein wenig Zeit, besonders wenn du z.B. eine neue Version hochladen möchtest.',
	'ACP_NEW_DESC'							=> 'Beschreibung',
	'ACP_NEW_DESC_EXPLAIN'					=> 'Gib hier eine Beschreibung für deinen Download ein.',
	'ACP_NEW_DL_CAT'						=> 'Kategorie',
	'ACP_NEW_DL_CAT_EXPLAIN'				=> 'Wähle hier die Kategorie, in welcher dein Download sich befinden soll.',
	'ACP_NEW_DOWNLOAD'						=> 'Neuer Download',
	'ACP_NEW_DOWNLOAD_EXPLAIN'				=> 'Hier kannst du neue Downloads hinzufügen.',
	'ACP_NEW_DOWNLOAD_SIZE'					=> 'Die von deinem Hoster erlaubte maximale Dateigröße beträgt <strong>%1$s %2$s</strong>! Abhängig von der Uploadzeit kann dieser Wert auch niedriger sein!',
	'ACP_NEW_FILENAME'						=> 'Dateiname',
	'ACP_NEW_FILENAME_EXPLAIN'				=> 'Wähle die Datei für den Upload aus.',
	'ACP_NEW_SUB_CAT_EXPLAIN'				=> 'Gib hier den Ordnernamen ein, welchen du auf deinem Webspace für diese Kategorie benutzen möchtest (ohne Schrägstriche!).<br />Dieses Verzeichnis wird dann automatisch erstellt unter root/ext/dmzx/downloadsystem/files/dein_Ordner.<br />Erlaubte Zeichen sind a-z, A-Z, 0-9, der Bindestrich ( - ), und der Unterstrich ( _ ).',
	'ACP_NEW_SUB_CAT_NAME'					=> 'Pfadname für die Kategorie',
	'ACP_NEW_TITLE'							=> 'Titel',
	'ACP_NEW_TITLE_EXPLAIN'					=> 'Gib hier den Titel für deinen neuen Download ein.',
	'ACP_NEW_VERSION'						=> 'Version',
	'ACP_NEW_VERSION_EXPLAIN'				=> 'Gib hier die Version deines Downloads ein.',
	'ACP_NO_CAT'							=> 'Es sind keine Kategorien verfügbar!<br />Du musst zuerst mindestens eine Kategorie erstellen, ehe du anfangen kannst Downloads hinzuzufügen!',
	'ACP_NO_CAT_ID'							=> 'Keine Kat-ID',
	'ACP_NO_CAT_PARENT'						=> 'keine übergeordnete Kategorie',
	'ACP_NO_CAT_UPLOAD'						=> 'Es sind keine Kategorien verfügbar!<br />Du musst zuerst mindestens eine Kategorie erstellen, ehe du anfangen kannst Dateien hinzuzufügen!',
	'ACP_NO_DOWNLOADS'						=> 'Keine Downloads',
	'ACP_NO_FILENAME'						=> 'Du musst eine Datei angeben, welche zu deinem Upload gehört!',
	'ACP_PAGINATION_ACP'					=> 'Stelle die Anzahl für die Seitenumbrüche auf der Seite „Downloads verwalten“ im ACP ein.',
	'ACP_PAGINATION_ACP_EXPLAIN'			=> 'Stelle hier ein, wieviele Einträge du auf der Seite „Downloads verwalten“ im ACP sehen möchtest. <em>Standard ist 5.</em>',
	'ACP_PAGINATION_DOWNLOADS'				=> 'Stelle die Anzahl für die Seitenumbrüche auf der Kategorieseite ein',
	'ACP_PAGINATION_DOWNLOADS_EXPLAIN'		=> 'Stelle hier ein, wieviele Einträge du auf der Kategorieseite im ACP sehen möchtest. <em>Standard ist 25.</em>',
	'ACP_PAGINATION_ERROR_ACP'				=> 'Du kannst keinen Wert einstellen, der kleiner ist als 5!',
	'ACP_PAGINATION_ERROR_USER'				=> 'Du kannst keinen Wert einstellen, der kleiner ist als 3!',
	'ACP_PAGINATION_ERROR_DOWNLOADS'		=> 'Du kannst keinen Wert einstellen, der kleiner ist als 10!',
	'ACP_PAGINATION_USER'					=> 'Stelle die Anzahl für die Seitenumbrüche auf der Downloadseite ein',
	'ACP_PAGINATION_USER_EXPLAIN'			=> 'Stelle hier ein, wieviele Einträge du auf der Downloadseite im ACP sehen möchtest. <em>Standard ist 3.</em>',
	'ACP_PARENT_OPTION_NAME'				=> 'Wähle eine Kategorie',
	'ACP_REALLY_DELETE'						=> 'Bist du sicher, dass du deinen Download löschen möchtest?<br />Die physische Datei auf dem Webserver wird ebenfalls gelöscht!',
	'ACP_SINGLE_DOWNLOAD'					=> '1 Download',
	'ACP_SORT_ASC'							=> 'Aufsteigend',
	'ACP_SORT_CAT'							=> 'Kategorie',
	'ACP_SORT_DESC'							=> 'Absteigend',
	'ACP_SORT_DIRECTION'					=> 'Sortierrichtung',
	'ACP_SORT_KEYS'							=> 'sortieren nach ',
	'ACP_SORT_TITLE'						=> 'Titel',
	'ACP_SUB_DL_CAT'						=> 'Unterkategorie',
	'ACP_SUB_NO_CAT'						=> '-----------',
	'ACP_SUB_DL_CAT_EXPLAIN'				=> 'Wähle hier die Unterkategorie.',
	'ACP_SUB_HAS_CAT_EXPLAIN'				=> 'Diese Kategorie hat Unterkategorien, und kann daher nicht mit anderen Kategorien verknüpft werden.',
	'ACP_UPLOAD_FILE_EXISTS'				=> 'Die Datei, die du hochladen möchtest, existiert bereits in dieser Kategorie!',
	'ACP_WRONG_CHAR'						=> 'Du hast ein nicht zugelassenes Zeichen im Pfadnamen für diese Kategorie!<br />Folgende Zeichen sind erlaubt: a-z, A-Z, 0-9, ebenso der Bindestrich ( - ), und der Unterstrich ( _ )!',
	'ACP_MANAGE_CONFIG_EXPLAIN'				=> 'Hier kannst du ein paar Basiswerte einstellen.',
	'ACP_SET_USERNAME'						=> 'Benutzername für eine Übertragung',
	'ACP_SET_USERNAME_EXPLAIN'				=> 'Hier kannst du einen Benutzernamen eingeben, welchem die Downloadkosten gesendet werden sollen. Leer lassen, wenn niemand die oben genannten Kosten erhalten soll.',
	'ACP_FTP_OR_UPLOAD'						=> 'Du kannst nur einen FTP-Upload <strong>ODER</strong> einen normalen Upload machen!',
	'ACP_NEW_FTP_FILENAME_EXPLAIN'			=> 'Gib hier den Dateinamen ein (z.B. beispiel.zip), wenn du die FTP-Upload-Methode nutzen möchtest.',
	'ACP_NEW_FTP_FILENAME'					=> 'FTP Dateiname',
	'ACP_UPLOAD_METHOD'						=> 'Upload Methode',
	'ACP_UPLOAD_METHOD_EXPLAIN'				=> 'Du kannst einen neuen Upload mittels FTP oder direkt hinzufügen. Wenn du die FTP-Upload-Methode benutzt, muss die Datei in die richtige Kategorie hochgeladen werden, <strong>bevor</strong> du sie hier benennst! Du kannst gleichzeitig jeweils nur die eine oder andere Methode verwenden!',
	'ACP_UPLOAD_FILE_NOT_EXISTS'			=> 'Die Datei existiert nicht in der genannten Kategorie. Da du die FTP-Upload-Methode ausgewählt hast, muss diese Datei über FTP in das richtige Verzeichnis hochgeladen werden<strong>BEVOR</strong> du sie hinzufügen kannst!',
	'ACP_DM_EDS_IMAGE_SIZE'					=> 'Maximale Bildgröße',
	'ACP_DM_EDS_IMAGE_SIZE_EXPLAIN'			=> 'Maximale Größe jeder Datei. Wenn der Wert 0 ist, wird die hochladbare Dateigröße lediglich begrenzt durch deine PHP-Konfiguration.<br>Durchschnittliche Größe von Bilddateien: PNG ~ 2–4 kB, GIF ~ 6–8 kB, JPG ~ 9–12 kB',
	'ACP_DM_EDS_IMAGE_DIR'					=> 'Bilderupload-Verzeichnis des Downloadsystems',
	'ACP_DM_EDS_IMAGE_DIR_EXPLAIN'			=> 'Speicherpfad für Blog-Bilder. Wenn du dieses Verzeichnis änderst, während du bereits Blog-Bilder hochgeladen hast, musst du die Dateien manuell an ihren neuen Speicherort kopieren.',
	'ACP_DM_EDS_IMAGE_CAT_DIR'				=> 'Verzeichnis zum Hochladen von Kategoriebildern',
	'ACP_DM_EDS_IMAGE_CAT_DIR_EXPLAIN'		=> 'Speicherpfad für Kategoriebilder. Wenn du dieses Verzeichnis änderst, während du bereits Kategoriebilder hochgeladen hast, musst du die Dateien manuell an ihren neuen Speicherort kopieren.',
	'ACP_DM_EDS_ALLOW_DL_IMG'				=> 'Download von Dateibildern erlauben',
	'ACP_DM_EDS_ALLOW_DL_IMG_EXPLAIN'		=> 'Erlauben, dass Bilder für Dateien angezeigt werden.',
	'ACP_DM_EDS_ALLOW_CAT_IMG'				=> 'Kategoriebilder erlauben',
	'ACP_DM_EDS_ALLOW_CAT_IMG_EXPLAIN'		=> 'Erlauben, dass Kategoriebilder angezeigt werden.',
	'ACP_DM_EDS_ALLOW_BBCODES'				=> 'BBCodes erlauben',
	'ACP_DM_EDS_ALLOW_BBCODES_EXPLAIN'		=> 'Die Verwendung von BBCodes innerhalb der Download System-Erweiterung erlauben.',
	'DM_EDS_ALLOW_SMILIES'					=> 'Smilies erlauben',
	'DM_EDS_ALLOW_SMILIES_EXPLAIN'			=> 'Die Verwendung von Smilies innerhalb der Download System-Erweiterung erlauben.',
	'ACP_DM_EDS_ALLOW_MAGIC_URL'			=> 'Links erlauben',
	'ACP_DM_EDS_ALLOW_MAGIC_URL_EXPLAIN'	=> 'Wenn dies verboten wird, sind die BBCodes <code>[URL]</code> und automatische/magic URLs innerhalb der Download System-Erweiterung deaktiviert.',
	'ACP_NEW_IMAGE_DL'						=> 'Bilder',
	'ACP_DL_DOWNLOAD_IMAGE'					=> 'Download image',
	'ACP_DL_DOWNLOAD_IMAGE_EXPLAIN'			=> 'Lade ein Bild für diese Datei hoch. Die maximale Dateigröße und das Dateiverzeichnis werden in den Konfigurationseinstellungen festgelegt.',
	'ACP_DL_DOWNLOAD_IMAGE_CURRENT'			=> 'Derzeitiges Bild',
	'ACP_CHANGEDLIMAGE'						=> 'Bild ändern?',
	'ACP_DL_CATEGORY_IMAGE'					=> 'Kategoriebild',
	'ACP_DL_CATEGORY_IMAGE_EXPLAIN'			=> 'Lade ein Bild für diese Datei hoch. Die maximale Dateigröße und das Dateiverzeichnis werden in den Konfigurationseinstellungen festgelegt.',
	'ACP_DL_CATEGORY_IMAGE_CURRENT'			=> 'Derzeitiges Bild',
	'ACP_CHANGECATIMAGE'					=> 'Bild ändern?',
	'ACP_DM_CATEGORIES'						=> '',
	'ACP_DM_CATEGORIES_IMAGE'				=> 'Bilder',
	'ACP_DM_CATEGORIES_NAME'				=> 'Kategoriename',
	'ACP_DM_CATEGORIES_DESC'				=> 'Beschreibung',
	'ACP_DM_CATEGORIES_SHOW_INDEX' 			=> 'Auf Upload-Seite anzeigen',
	'ACP_SHOW_DONATION'						=> 'Spenden-Button vor dem Herunterladen einer Datei anzeigen',
	'ACP_SHOW_DONATION_EXPLAIN' 			=> 'Zeigt beim Herunterladen einer Datei den Spendenbutton an.',
	'ACP_DONATION_URL'						=> 'URL zur Spendenseit',
	'ACP_DONATION_URL_EXPLAIN' 				=> 'URL zur Spendenseite einstellen. Wird in einem neuen Tab geöffnet, und der Download startet automatisch.',
));
