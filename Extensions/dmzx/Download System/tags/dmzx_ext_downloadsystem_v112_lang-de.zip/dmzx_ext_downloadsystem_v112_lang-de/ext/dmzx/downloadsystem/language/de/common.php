<?php
/**
*
* @package phpBB Extension - Download System (deutsch)
* @version $Id: common.php 42 2017-01-06 12:34:40Z Scanialady $
* @copyright (c) 2016 dmzx - https://www.dmzx-web.net
* @license https://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
// ‚ ‘ ’ « » „ “ ” …
//

$lang = array_merge($lang, array(
	'EDS_BACK_INDEX'					=> 'Zurück zum Verzeichnis',
	'EDS_BACK_LINK'						=> 'Klicke %shier%s, um zum Downloadverzeichnis zurückzukehren',
	'EDS_CATS_NAME'						=> 'Kategorien',
	'EDS_CAT_DESC'						=> 'Beschreibung',
	'EDS_CAT_NAME'						=> 'Kategorie',
	'EDS_CAT_IMAGE'						=> 'Bild',	
	'EDS_COST'							=> 'Kosten',
	'EDS_COST_ERROR'					=> 'Du brauchst mehr %1$s um diese Datei herunterzuladen.',
	'EDS_COST_FREE'						=> 'Dieser Download ist kostenlos',
	'EDS_COST_OK'						=> 'Du hast genug %1$s, um diese Datei herunterzuladen.',
	'EDS_DISABLED'						=> 'Das Downloadsystem ist derzeit deaktiviert. Bitte versuche es später noch einmal.<br />Wenn du später noch immer die gleiche Meldung erhältst, informiere bitte den Administrator.',
	'EDS_DL_NOEXISTS'					=> 'Dieser Download existiert nicht.',
	'EDS_DOWNLOAD'						=> 'Download',
	'EDS_DOWNLOADS'						=> 'Downloads',
	'EDS_DOWNLOAD_FILE'					=> 'Download File',
	'EDS_DOWNLOAD_DONATE'				=> 'Spende',
	'EDS_DOWNLOAD_DONATE_THX'			=> 'Danke für deine Spende!',
	'EDS_DOWNLOAD_DONATE_MES'			=> 'Möchtest du vielleicht auch eine kleine <strong>Spende</strong> hinterlassen, <br />oder einfach nur die Datei  <strong>herunterladen</strong>?',
	'EDS_DOWNLOAD_START'				=> 'Dein Download startet in Kürze!',
	'EDS_DOWNLOAD_NO_PERM'				=> 'Keine ausreichende Berechtigung!',
	'EDS_DOWNLOAD_NOT_DOWNLOAD'			=> 'Du kannst diese Datei nicht herunterladen!',
	'EDS_DOWNLOAD_REDIRECT'				=> 'Weiterleitung',	
	'EDS_DOWNLOAD_EXPLAIN'				=> 'Klicke rechts auf das Icon, um die gewünschte Datei herunterzuladen.',
	'EDS_FILE_CLICKS'					=> 'Gesamte Downloads',
	'EDS_FILE_DESC'						=> 'Beschreibung',
	'EDS_FILE_TITLE'					=> 'Dateiname',
	'EDS_FILE_VERSION'					=> 'Version',
	'EDS_FREE'							=> 'Kostenlos',
	'EDS_INDEX'							=> 'Verzeichnis',
	'EDS_LAST_CHANGED_ON'				=> 'Zuletzt geändert am',
	'EDS_LAST_DOWNLOAD'					=> '&nbsp;<strong>%1$s</strong><br /><br />&nbsp;Heruntergeladen: %2$s<br />&nbsp;Zuletzt geändert am: %3$s',
	'EDS_LAST_FILE'						=> 'Neueste Datei',
	'EDS_LEGEND'						=> 'Legende',
	'EDS_LEGEND_ERROR'					=> 'Du benötigst mehr %1$s',
	'EDS_LEGEND_FREE'					=> 'Der Download ist kostenlos',
	'EDS_LEGEND_NO_DL'					=> 'Du bist nicht berechtigt, Dateien herunterzuladen',
	'EDS_LEGEND_OK'						=> 'Du hast ausreichend %1$s',
	'EDS_MULTI'							=> '%1$s Downloads',
	'EDS_NO_CAT'						=> '<strong>Entschuldige! Derzeit sind keine Kategorien verfügbar.</strong><br /><br />',
	'EDS_NO_CAT_IN_UPLOAD'				=> 'Entschuldige! Derzeit sind keine Kategorien vorhanden.',
	'EDS_NO_DOWNLOADS'					=> '<strong>Entschuldige! Derzeit sind keine Downloads verfügbar.</strong><br /><br />',
	'EDS_NO_FILES'						=> 'Es gibt keine Downloads.',
	'EDS_NO_ID'							=> 'Keine ID angegeben.',
	'EDS_NUMBER_DOWNLOADS'				=> 'Dateien',
	'EDS_REGULAR_DOWNLOAD'				=> 'Klicke hier, um die ausgewählte Datei herunterzuladen',
	'EDS_REQUIRES_POINTS'				=> '<strong>Weil wir die Ultimate Points Erweiterung installiert haben, und du Punkte für diesen Download benötigst, <br />musst du angemeldet sein, ehe du diese Datei herunterladen kannst!</strong>',
	'EDS_SINGLE'						=> '1 Download',
	'EDS_SUB_CAT'						=> 'Unterkategorie',
	'EDS_SUB_CATS'						=> 'Unterkategorien',
	'EDS_TITLE'							=> 'Downloads',
	'EDS_TITLE_EXPLAIN'					=> 'Wähle unten eine Kategorie',
	'EDS_UPLOADED_ON'					=> 'Hochgeladen am',
	'EDS_UPLOAD'						=> 'Upload',
	'EDS_UPLOADS'						=> 'Downloadsystem Uploadbereich',
	'EDS_UPLOAD_SECTION'				=> 'Uploadbereich',
	'EDS_UPLOAD_MESSAGE'				=> 'Lade hier deine Datei in die richtige Kategorie hoch.',
	'EDS_FILESIZE'						=> 'Dateigröße',
	'EDS_CAT_NOT_EXIST'					=> 'Die ausgewählte Kategorie existiert nicht!',
	'EDS_BACK_DOWNLOADS'				=> 'Zurück zur Downloadübersicht',
	'EDS_NO_PERMISSION'					=> 'Du hast keine ausreichende Berechtigung, das Downloadsystem zu benutzen',
	'EDS_NO_DOWNLOAD'					=> 'Du hast keine ausreichende Berechtigung, Dateien aus dem Downloadsystem herunterzuladen',
	'EDS_NO_UPLOAD'						=> 'Du hast keine ausreichende Berechtigung, den Uploadbereich zu benutzen',
	'EDS_NO_DIRECT_DL'					=> 'Es ist dir nicht erlaubt, Dateien herunterzuladen',
	'EDS_CAT'							=> '%d Kategorie',
	'EDS_CATS'							=> '%d Kategorien',
	'EDS_SUB_CATEGORY'					=> 'und %d Unterkategorie',
	'EDS_SUB_CATEGORIES'				=> 'und %d Unterkategorien',	
	'EDS_CURRENT_VERSION'				=> 'Derzeitige Version',
	'EDS_NEW_TITLE'						=> 'Titel',
	'EDS_NEW_TITLE_EXPLAIN'				=> 'Titel für deinen neuen Download.',
	'EDS_NEW_VERSION'					=> 'Version',
	'EDS_NEW_VERSION_EXPLAIN'			=> 'Version deines Downloads.',
	'EDS_NEW_DESC'						=> 'Beschreibung',
	'EDS_NEW_DESC_EXPLAIN'				=> 'Gib hier eine Beschreibung für deinen Download ein.',
	'EDS_NEW_DL_CAT'					=> 'Kategorie',
	'EDS_NEW_DL_CAT_EXPLAIN'			=> 'Wähle hier die Kategorie aus.',
	'EDS_NEW_DOWNLOAD'					=> 'Neuer Download',
	'EDS_NEW_FILENAME'					=> 'Dateiname',
	'EDS_NEW_FILENAME_EXPLAIN'			=> 'Wähle die Datei zum Hochladen aus.',
	'EDS_NEW_DOWNLOAD_SIZE'				=> 'Die maximale Dateigröße ist <strong>%1$s %2$s</strong>! Wegen der Zeit, die du zum Hochladen brauchst, kann dieser Wert niedriger sein!',
	'EDS_SUBCAT_FILE'					=> '1 Datei',
	'EDS_SUBCAT_FILES'					=> '%1$d Dateien',
	'EDS_DL_IMAGE'						=> 'Bild',
	'EDS_UPLOAD_FILE_EXISTS'			=> 'Die Datei, welche du hochladen möchtest, existiert bereits in dieser Kategorie!',
	'EDS_NO_FILENAME'					=> 'Du musst eine Datei angeben, welche zu deinem Upload gehört!',
	'EDS_FILE_TOO_BIG'					=> 'Die Datei ist größer, als dein Hoster erlaubt!',	
	'EDS_CLICK'							=> 'hier',
	'EDS_ANNOUNCE_TITLE'				=> '%1$s',
	'EDS_ANNOUNCE_MSG'					=> 'Hallo,
	
wir haben einen neuen Download!

[b]Titel:[/b] %1$s
[b]Beschreibung:[/b] %2$s
[b]Kategorie:[/b] %3$s
[b]Klicke %4$s, um zur Downloadseite zu gehen![/b]

Viel Spaß!',
	'EDS_NEW_ADDED'							=> 'Dein Eintrag wurde erfolgreich der Datenbank hinzugefügt.',
));
