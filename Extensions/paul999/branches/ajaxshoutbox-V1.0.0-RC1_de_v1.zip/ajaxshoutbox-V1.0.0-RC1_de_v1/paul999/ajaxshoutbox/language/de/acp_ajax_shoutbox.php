<?php
/**
 *
 * Ajax Shoutbox extension for the phpBB Forum Software package [German].
 * Translated by Scanialady <http://ladyscommunity.de> 2015-03-26
 * @copyright (c) 2014 Paul Sohier <http://www.ajax-shoutbox.com>
 * @license       GNU General Public License, version 2 (GPL-2.0)
 *
 */

/**
 * DO NOT CHANGE
 */
if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

// DEVELOPERS PLEASE NOTE
//
// All language files should use UTF-8 as their encoding and the files must not contain a BOM.
//
// Placeholders can now contain order information, e.g. instead of
// 'Page %s of %s' you can (and should) write 'Page %1$s of %2$s', this allows
// translators to re-order the output of data while ensuring it remains correct
//
// You do not need this where single placeholders are used, e.g. 'Message %d' is fine
// equally where a string contains only two placeholders which are used to wrap text
// in a url you again do not need to specify an order e.g., 'Click %sHERE%s' is fine
//
// Some characters you may want to copy&paste:
//  ‚ ‘ ’ « » „ “ ” …
//

$lang = array_merge(
	$lang, array(
		'ACP_AJAXSHOUTBOX_SETTINGS'     => 'Ajax Shoutbox Einstellungen',
		'ACP_AJAXSHOUTBOX_SETTINGS_EXPLAIN'     => 'Auf dieser Seite kannst du die Einstellungen speziell für die Shoutbox ändern. <br /><br />
			Wenn du deinen Benutzern ermöglichen möchtest, die iOS und Android APPs zu benutzen (derzeit in einer geschlossenen Beta, aber Benutzer können es mit 
			deinem Board verwenden, wenn sie Zugang zur Beta haben.
			Siehe <a href="http://www.ajax-shoutbox.com/viewtopic.php?f=2&t=9">hier</a> mehr Information), musst du einen Account erstellen auf
			<a href="https://www.shoutbox-app.com/">www.shoutbox-app.com</a> und ein neues Forum hinzufügen. Du wirst nach einem Aktivierungscode gefragt werden. Dieser Code wird unten angezeigt.
		',

		'ACP_AJAXSHOUTBOX_PRUNE'        => 'Löscheinstellungen',
		'AJAXSHOUTBOX_ENABLE_PRUNE'     => 'Aktiviere Beschneidung der Beiträge',
		'AJAXSHOUTBOX_PRUNE_DAYS'       => 'Beschneide Beiträge nach',

		'AJAXSHOUTBOX_DEFAULT_DATE_FORMAT'  => 'Datumsformat',
		'AJAXSHOUTBOX_DEFAULT_DATE_FORMAT_EXPLAIN'  => 'Standard-Datumsformat für die Shoutbox. Du solltest nicht die relativen Daten benutzen, das Datum würde sich nicht aktualisieren, wenn die Shoutbox aktualisiert wird.',

		'ACP_AJAXSHOUTBOX_PUSH'         => 'App-Konfiguration',
		'AJAXSHOUTBOX_ACTIVATION_KEY'   => 'Aktivierungscode',
		'ACP_AJAXSHOUTBOX_ENABLE_PUSH'  => 'Aktiviere Android und iOS App',
		'ACP_AJAXSHOUTBOX_ENABLE_PUSH_EXPLAIN'  => 'Bevor du deine Seite registrieren kannst, musst du diese Funktion aktivieren.',
		'ACP_AJAXSHOUTBOX_API_KEY_PUSH' => 'API Key',
		'ACP_AJAXSHOUTBOX_API_KEY_PUSH_EXPLAIN' => 'Du wirst diesen Schlüssel erhalten, nachdem du dein Forum auf www.shoutbox-app.com hinzugefügt hast.',
		'ACP_AJAXSHOUTBOX_CON_KEY_PUSH' => 'Verbindungs-ID',
		'ACP_AJAXSHOUTBOX_CON_KEY_PUSH_EXPLAIN' => 'Du wirst diesen Schlüssel erhalten, nachdem du dein Forum auf www.shoutbox-app.com hinzugefügt hast.<br />Deine Benutzer müssen diese ID benutzen, um dein Board in der App zu finden.',
	
		'ACP_AJAXSHOUTBOX_PUSH_DISABLED'            => 'Push-Funktionalität deaktiviert',
		'ACP_AJAXSHOUTBOX_PUSH_DISABLED_EXPLAIN'    => 'Die Push-Funktionalität ist standardmäßig deaktiviert. Wenn du diese Funktion benutzen möchtest, füge die folgende Zeile der config.php hinzu: ',
	)
);
