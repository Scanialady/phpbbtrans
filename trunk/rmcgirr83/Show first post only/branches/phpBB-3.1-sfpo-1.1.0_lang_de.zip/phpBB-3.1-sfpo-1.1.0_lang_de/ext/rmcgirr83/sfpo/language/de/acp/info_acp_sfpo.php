<?php
/**
*
* @package Show first post only to guest
* @copyright (c) 2016 Rich McGirr (RMcGirr83)
* @license http://opensource.org/licenses/gpl-2.0.php GNU General Public License v2
*
*/

if (!defined('IN_PHPBB'))
{
	exit;
}

if (empty($lang) || !is_array($lang))
{
	$lang = array();
}

$lang = array_merge($lang, array(
	// ACP
	'ENABLE_SFPO' 			=> 'Show first post only to guest aktivieren',
	'ENABLE_SFPO_EXPLAIN' 	=> 'Wenn dies auf Ja gesetzt wird, können unregistrierte Benutzer / Gäste nur noch den ersten Beitrag eines Themas sehen. Der Rest der Beiträge in einem Thema wird sie dazu anhalten, sich zu registrieren oder anzumelden.',
	'SFPO_CHARACTERS'		=> 'Anzahl der anzuzeigenden Zeichen',
	'SFPO_CHARACTERS_EXPLAIN'	=> 'Gib die Anzahl der Zeichen ein, die aus dem ersten Beitrag anzuzeigen sind (Standard ist 150). Den Wert auf 0 zu setzen deaktiviert diese Funktion.',
	'SFPO_CHARS'			=> 'Zeichen',
));
